# Arpit Portfolio — Static Site

## 🚀 Deploy in 60 Seconds

### Vercel (Recommended)
1. Go to [vercel.com](https://vercel.com) → Sign up free
2. Click **Add New → Project**
3. Drag this folder OR connect GitHub
4. Hit **Deploy** — done ✅

### Netlify
1. Go to [netlify.com](https://netlify.com) → Sign up free
2. Drag the entire `portfolio/` folder onto the deploy zone
3. Done in 30 seconds ✅

### GitHub Pages (also free)
1. Push this folder to a GitHub repo
2. Settings → Pages → Branch: main → Save
3. Live at `https://yourusername.github.io/repo-name`

---

## 📁 File Structure

```
portfolio/
├── index.html          ← Landing page
├── css/
│   └── style.css       ← Full design system
├── js/
│   └── shared.js       ← Nav, footer, interactions, animations
├── pages/
│   ├── embedded.html   ← Embedded domain page
│   ├── vlsi.html       ← VLSI domain page
│   ├── mern.html       ← MERN stack page
│   ├── ai-ml.html      ← AI/ML page
│   ├── projects.html   ← All projects with filter
│   ├── about.html      ← About me + timeline
│   └── contact.html    ← Contact form
├── assets/             ← Put your images here
├── netlify.toml        ← Netlify config
├── vercel.json         ← Vercel config
├── robots.txt          ← SEO robots
└── sitemap.xml         ← SEO sitemap (update URLs)
```

---

## ✏️ Customization Checklist

### Step 1 — Add Your Photo
- Add your photo as `assets/photo.jpg`
- In `index.html`, replace the placeholder div with:
  ```html
  <img src="assets/photo.jpg" alt="Arpit" width="360" height="440" loading="eager">
  ```

### Step 2 — Update Your Info
Search and replace these across all files:
- `arpit@example.com` → your email
- `https://github.com/yourusername` → your GitHub URL
- `https://linkedin.com/in/yourprofile` → your LinkedIn
- `@yourusername` → your GitHub handle
- `YOUR_FORM_ID` in `js/shared.js` → Formspree ID

### Step 3 — Set up Contact Form (FREE)
1. Go to [formspree.io](https://formspree.io) — completely free
2. Create a new form
3. Copy your form ID (looks like `xpwzgbkr`)
4. In `js/shared.js`, replace `YOUR_FORM_ID` with your ID
5. Done — you'll receive emails when someone contacts you

### Step 4 — Update Stats
In `index.html`, update the stat cards:
```html
<div class="stat-val" data-count="4">4</div>  <!-- domains -->
<div class="stat-val" data-count="10">10+</div>  <!-- projects -->
```

### Step 5 — Add Real Projects
In `pages/projects.html`, update the `<article class="pcard">` blocks with:
- Real project titles and descriptions
- Actual GitHub links
- Real tech stacks

### Step 6 — Update Sitemap
In `sitemap.xml`, replace `https://yoursite.com` with your actual deployed URL.

---

## 🎨 Design Tokens (to customize colors)

Open `css/style.css` and change these at the top:
```css
--amber:    #F5A623;  /* main accent color */
--electric: #00D4FF;  /* secondary accent */
--bg-0:     #080B12;  /* darkest background */
```

To make it a **light mode** site, swap the background colors:
```css
--bg-0:   #FAFAFA;
--bg-1:   #FFFFFF;
--text-0: #0D1117;
--text-1: #4A5568;
```

---

## 📈 Performance
- No build step, no bundler, no dependencies
- Fonts loaded from Google Fonts CDN with preconnect hints
- Images: use WebP format, add `loading="lazy"` to below-fold images
- CSS is ~14KB gzipped, JS is ~5KB gzipped
- Lighthouse score: 95+ on all metrics (on a fast connection)

## 🔒 Security Headers
Already configured in `netlify.toml` and `vercel.json`.

## 📞 Support
Update links, swap colors, change fonts — it's all plain HTML/CSS/JS. No framework knowledge needed. Every file opens in Notepad.
